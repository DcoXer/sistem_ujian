<?php echo $__env->make('errors.partials.themed', [
    'code' => 403,
    'title' => 'Akses Ditolak',
    'message' => 'Anda tidak memiliki izin untuk membuka halaman atau menjalankan aksi ini.',
], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\laragon\www\website_ujian\resources\views/errors/403.blade.php ENDPATH**/ ?>