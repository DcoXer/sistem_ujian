<section
    id="kelola-ujian"
    class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"
    data-admin-dashboard-realtime-url="<?php echo e(route('admin.dashboard.realtime')); ?>"
>
    <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
            <h2 class="text-lg font-semibold text-slate-900">Kelola Ujian</h2>
            <p class="text-sm text-slate-500">Buat draft ujian, review soal dari author, lalu publish.</p>
        </div>
        <div class="flex flex-wrap gap-2">
            <a href="<?php echo e(route('admin.exams.index')); ?>" class="inline-flex items-center rounded-lg border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-100">Lihat Semua</a>
        </div>
    </div>

    <div class="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3" data-admin-latest-exams>
        <?php $__empty_1 = true; $__currentLoopData = $latestExams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <article class="rounded-xl border border-slate-200 p-4">
                <div class="flex items-start justify-between gap-2">
                    <p class="text-sm font-semibold text-slate-900"><?php echo e($exam->title); ?></p>
                    <span class="rounded bg-slate-100 px-2 py-1 text-[10px] font-semibold uppercase text-slate-700"><?php echo e($exam->status); ?></span>
                </div>
                <p class="mt-2 text-xs text-slate-500"><?php echo e($exam->start_at?->format('d M Y H:i')); ?> - <?php echo e($exam->end_at?->format('d M Y H:i')); ?></p>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-sm text-slate-500" data-admin-latest-exams-empty>Belum ada data ujian.</p>
        <?php endif; ?>
    </div>
</section>

<section id="kelola-operator" class="grid gap-4 lg:grid-cols-2">
    <div class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div class="mb-3 flex items-center justify-between">
            <h3 class="text-base font-semibold text-slate-900">Operator Aktif</h3>
            <a href="<?php echo e(route('admin.users.index')); ?>" class="text-xs font-semibold text-slate-600 hover:text-slate-900">Kelola User</a>
        </div>
        <div class="space-y-2">
            <?php $__empty_1 = true; $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex items-center justify-between rounded-lg border border-slate-200 px-3 py-2">
                    <div>
                        <p class="text-sm font-medium text-slate-900"><?php echo e($operator->name); ?></p>
                        <p class="text-xs text-slate-500"><?php echo e($operator->email); ?></p>
                    </div>
                    <span class="rounded bg-emerald-50 px-2 py-1 text-[10px] font-semibold uppercase text-emerald-700">Aktif</span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-sm text-slate-500">Belum ada operator.</p>
            <?php endif; ?>
        </div>
    </div>

    <div id="laporan-ujian" class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <h3 class="mb-3 text-base font-semibold text-slate-900">Top Nilai Peserta</h3>
        <div class="space-y-2">
            <?php $__empty_1 = true; $__currentLoopData = $myScores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-sm">
                    <span class="text-slate-800"><?php echo e($score->match_title); ?></span>
                    <span class="font-semibold text-slate-900"><?php echo e((int) $score->score); ?> pts</span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-sm text-slate-500">Belum ada data nilai.</p>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH C:\laragon\www\website_ujian\resources\views/dashboard/role-admin.blade.php ENDPATH**/ ?>