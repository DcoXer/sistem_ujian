<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold text-gray-800">Manajemen Ujian</h2>
     <?php $__env->endSlot(); ?>

    <?php
        $hasExamFormErrors = $errors->has('title') || $errors->has('start_at') || $errors->has('end_at') || $errors->has('authoring_start_at') || $errors->has('authoring_end_at') || $errors->has('duration_minutes');
        $modalMode = request()->query('modal');
    ?>

    <div class="mx-auto max-w-6xl px-4 py-6">
        <div class="mb-4">
            <?php if (isset($component)) { $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-button','data' => ['href' => route('dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('dashboard'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $attributes = $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $component = $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
        </div>

        <div class="mb-4 grid gap-3 md:grid-cols-4">
            <div class="rounded-xl border border-gray-200 bg-white p-4">
                <p class="text-xs uppercase text-gray-500">Create</p>
                <p class="mt-1 text-sm font-semibold text-gray-900">Ujian dibuat sebagai draft</p>
            </div>
            <div class="rounded-xl border border-gray-200 bg-white p-4">
                <p class="text-xs uppercase text-gray-500">Publish</p>
                <p class="mt-1 text-sm font-semibold text-gray-900">Publish hanya jika soal sudah ada</p>
            </div>
            <div class="rounded-xl border border-gray-200 bg-white p-4">
                <p class="text-xs uppercase text-gray-500">Lock</p>
                <p class="mt-1 text-sm font-semibold text-gray-900">Setelah publish, soal terkunci</p>
            </div>
            <div class="rounded-xl border border-gray-200 bg-white p-4">
                <p class="text-xs uppercase text-gray-500">Result</p>
                <p class="mt-1 text-sm font-semibold text-gray-900">Hasil dipantau dari laporan</p>
            </div>
        </div>

        <div class="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <p class="text-sm text-gray-600">Buat, review, dan publish ujian.</p>
            <button id="open-exam-create" type="button" class="inline-flex w-full items-center justify-center rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700 sm:w-auto">Buat Ujian</button>
        </div>

        
        <div class="space-y-3 md:hidden">
            <?php $__empty_1 = true; $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <div class="flex items-start justify-between gap-3">
                        <h3 class="text-sm font-semibold text-gray-900"><?php echo e($exam->title); ?></h3>
                        <span class="rounded px-2 py-1 text-[10px] uppercase <?php echo e($exam->status === 'draft' ? 'bg-amber-100 text-amber-800' : ($exam->status === 'running' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700')); ?>">
                            <?php echo e($exam->status); ?>

                        </span>
                    </div>
                    <p class="mt-2 text-xs text-gray-600">Author: <?php echo e($exam->author?->name ?? '-'); ?></p>
                    <p class="mt-1 text-xs text-gray-600"><?php echo e($exam->start_at); ?> - <?php echo e($exam->end_at); ?></p>
                    <p class="mt-1 text-xs text-gray-600">Batas Waktu: <?php echo e($exam->authoring_start_at?->format('d M Y H:i') ?? '-'); ?> - <?php echo e($exam->authoring_end_at?->format('d M Y H:i') ?? '-'); ?></p>
                    <?php ($isAuthoringOpen = $exam->status === 'draft' && $exam->isWithinAuthoringWindow()); ?>
                    <?php ($isPublishLockedByAuthoring = $exam->status === 'draft' && ! $exam->isAuthoringWindowClosed()); ?>
                    <div class="mt-2">
                        <span class="rounded px-2 py-1 text-[10px] font-semibold uppercase <?php echo e($isAuthoringOpen ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'); ?>">
                            <?php echo e($isAuthoringOpen ? 'authoring_open' : 'authoring_closed'); ?>

                        </span>
                        <span class="ml-1 rounded px-2 py-1 text-[10px] font-semibold uppercase <?php echo e($isPublishLockedByAuthoring ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'); ?>">
                            <?php echo e($isPublishLockedByAuthoring ? 'publish_locked_by_authoring_window' : 'publish_window_ready'); ?>

                        </span>
                    </div>
                    <div class="mt-3 grid grid-cols-2 gap-2 text-xs">
                        <div class="rounded bg-slate-50 px-2 py-1 text-slate-600">Soal: <span class="font-semibold text-slate-900"><?php echo e($exam->questions_count); ?></span></div>
                        <div class="rounded bg-slate-50 px-2 py-1 text-slate-600">Attempt: <span class="font-semibold text-slate-900"><?php echo e($exam->attempts_count); ?></span></div>
                    </div>
                    <div class="mt-3 flex items-center gap-2">
                        <a href="<?php echo e(route('admin.exams.show', $exam)); ?>" class="rounded border border-indigo-200 bg-indigo-50 px-3 py-1 text-xs font-semibold text-indigo-700 hover:bg-indigo-100">Detail</a>
                        <?php if($exam->status === 'draft'): ?>
                            <form method="POST" action="<?php echo e(route('admin.exams.destroy', $exam)); ?>" data-confirm data-confirm-title="Hapus Exam" data-confirm-message="Exam draft ini akan dihapus permanen. Lanjutkan?">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="rounded border border-rose-200 bg-rose-50 px-3 py-1 text-xs font-semibold text-rose-700 hover:bg-rose-100">
                                    Hapus
                                </button>
                            </form>
                        <?php else: ?>
                            <span class="rounded bg-slate-100 px-2 py-1 text-[10px] uppercase text-slate-600">Read-only</span>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="rounded-xl border border-gray-200 bg-white px-4 py-6 text-center text-sm text-gray-500">Belum ada exam.</div>
            <?php endif; ?>
        </div>

        
        <div class="-mx-4 hidden px-4 md:block">
            <div class="overflow-x-auto rounded-xl border border-gray-200 bg-white [scrollbar-gutter:stable]">
                <table class="w-full min-w-[1080px] text-sm">
                <thead class="bg-gray-50 text-center text-gray-600">
                    <tr>
                        <th class="px-4 py-3 font-medium">Judul</th>
                        <th class="px-4 py-3 font-medium">Author</th>
                        <th class="px-4 py-3 font-medium">Waktu</th>
                        <th class="px-4 py-3 font-medium">Status</th>
                        <th class="px-4 py-3 font-medium">Soal</th>
                        <th class="px-4 py-3 font-medium">Attempt</th>
                        <th class="px-4 py-3 font-medium text-right">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border-t border-gray-100">
                            <td class="px-4 py-3 font-medium text-gray-900"><?php echo e($exam->title); ?></td>
                            <td class="px-4 py-3 text-gray-700">
                                <?php echo e($exam->author?->name ?? '-'); ?>

                            </td>
                            <td class="px-4 py-3 text-gray-600">
                                <p class="mt-1 text-ms text-green-600"><?php echo e($exam->start_at?->format('d M Y H:i') ?? '-'); ?> <br> <?php echo e($exam->end_at->format('d M Y H:i') ?? '-'); ?></p>
                                <p class="mt-1 text-xs text-rose-700">Batas Waktu: <br> <?php echo e($exam->authoring_start_at?->format('d M Y H:i') ?? '-'); ?> <br> <?php echo e($exam->authoring_end_at?->format('d M Y H:i') ?? '-'); ?></p>
                                <?php ($isAuthoringOpen = $exam->status === 'draft' && $exam->isWithinAuthoringWindow()); ?>
                                <?php ($isPublishLockedByAuthoring = $exam->status === 'draft' && ! $exam->isAuthoringWindowClosed()); ?>
                                <span class="mt-1 inline-flex rounded px-2 py-1 text-[10px] font-semibold uppercase <?php echo e($isAuthoringOpen ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700'); ?>">
                                    <?php echo e($isAuthoringOpen ? 'Soal sedang dibuat' : 'soal ditutup'); ?>

                                </span>
                            </td>
                            <td class="px-4 py-3">
                                <span class="rounded px-2 py-1 text-xs uppercase <?php echo e($exam->status === 'draft' ? 'bg-amber-100 text-amber-800' : ($exam->status === 'running' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-700')); ?>">
                                    <?php echo e($exam->status); ?>

                                </span>
                            </td>
                            <td class="px-4 py-3 text-gray-700"><?php echo e($exam->questions_count); ?></td>
                            <td class="px-4 py-3 text-gray-700"><?php echo e($exam->attempts_count); ?></td>
                            <td class="min-w-[190px] whitespace-nowrap px-4 py-3 text-right">
                                <div class="inline-flex items-center justify-end gap-2">
                                    <a href="<?php echo e(route('admin.exams.show', $exam)); ?>" class="text-indigo-600 hover:underline">Detail</a>
                                    <?php if($exam->status === 'draft'): ?>
                                        <form method="POST" action="<?php echo e(route('admin.exams.destroy', $exam)); ?>" class="inline-block" data-confirm data-confirm-title="Hapus Exam" data-confirm-message="Exam draft ini akan dihapus permanen. Lanjutkan?">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="rounded border border-rose-200 bg-rose-50 px-2 py-1 text-[10px] font-semibold uppercase text-rose-700 hover:bg-rose-100">
                                                Hapus
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="rounded bg-slate-100 px-2 py-1 text-[10px] uppercase text-slate-600">Read-only</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="7" class="px-4 py-6 text-center text-gray-500">Belum ada exam.</td></tr>
                    <?php endif; ?>
                </tbody>
                </table>
            </div>
        </div>
    </div>

    <div id="exam-modal" class="fixed inset-0 z-[105] hidden">
        <div class="exam-modal-backdrop absolute inset-0 bg-slate-900/60"></div>
        <div class="relative z-10 flex min-h-full items-center justify-center p-4">
            <div class="w-full max-w-2xl rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
                <div class="mb-4 flex items-center justify-between">
                    <h3 class="text-xl font-bold text-slate-900">Buat Exam</h3>
                    <button type="button" class="close-exam-modal rounded-lg border border-slate-300 px-2 py-1 text-sm text-slate-600 hover:bg-slate-100">Tutup</button>
                </div>

                <?php if($hasExamFormErrors): ?>
                    <div class="mb-4 rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">
                        Periksa kembali input form exam.
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('admin.exams.store')); ?>" class="space-y-4">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-gray-700">Judul</label>
                        <input name="title" value="<?php echo e(old('title')); ?>" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" required>
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-xs text-rose-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="grid gap-4 sm:grid-cols-2">
                        <div>
                            <label class="mb-1 block text-sm font-medium text-gray-700">Mulai</label>
                            <input type="datetime-local" name="start_at" value="<?php echo e(old('start_at')); ?>" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" required>
                            <?php $__errorArgs = ['start_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-xs text-rose-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label class="mb-1 block text-sm font-medium text-gray-700">Selesai</label>
                            <input type="datetime-local" name="end_at" value="<?php echo e(old('end_at')); ?>" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" required>
                            <?php $__errorArgs = ['end_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-xs text-rose-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="grid gap-4 sm:grid-cols-2">
                        <div>
                            <label class="mb-1 block text-sm font-medium text-gray-700">Mulai Authoring Soal</label>
                            <input type="datetime-local" name="authoring_start_at" value="<?php echo e(old('authoring_start_at')); ?>" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" required>
                            <?php $__errorArgs = ['authoring_start_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-xs text-rose-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div>
                            <label class="mb-1 block text-sm font-medium text-gray-700">Selesai Authoring Soal</label>
                            <input type="datetime-local" name="authoring_end_at" value="<?php echo e(old('authoring_end_at')); ?>" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" required>
                            <?php $__errorArgs = ['authoring_end_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="mt-1 text-xs text-rose-600"><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-gray-700">Durasi (menit)</label>
                        <input type="number" min="1" name="duration_minutes" value="<?php echo e(old('duration_minutes')); ?>" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" required>
                        <?php $__errorArgs = ['duration_minutes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-xs text-rose-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div>
                        <label class="mb-1 block text-sm font-medium text-gray-700">Author Penanggung Jawab Soal</label>
                        <select name="author_id" class="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm" required>
                            <option value="">Pilih author</option>
                            <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($author->id); ?>" <?php echo e((string) old('author_id') === (string) $author->id ? 'selected' : ''); ?>>
                                    <?php echo e($author->name); ?> (<?php echo e($author->email); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['author_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1 text-xs text-rose-600"><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="flex items-center justify-end gap-2">
                        <button type="button" class="close-exam-modal rounded-lg border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-100">Batal</button>
                        <button class="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700">Simpan Draft</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const modal = document.getElementById('exam-modal');
            if (!modal) return;

            const openBtn = document.getElementById('open-exam-create');
            const closeButtons = modal.querySelectorAll('.close-exam-modal');
            const backdrop = modal.querySelector('.exam-modal-backdrop');

            const openModal = () => modal.classList.remove('hidden');
            const closeModal = () => modal.classList.add('hidden');

            openBtn?.addEventListener('click', openModal);
            closeButtons.forEach((btn) => btn.addEventListener('click', closeModal));
            backdrop?.addEventListener('click', closeModal);

            const hasErrors = <?php echo json_encode($hasExamFormErrors, 15, 512) ?>;
            const modalMode = <?php echo json_encode($modalMode, 15, 512) ?>;
            if (hasErrors || modalMode === 'create') {
                openModal();
            }
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\website_ujian\resources\views/admin/exams/index.blade.php ENDPATH**/ ?>