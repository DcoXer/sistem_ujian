<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold text-gray-800"><?php echo e($exam->title); ?></h2>
     <?php $__env->endSlot(); ?>

    <div class="mx-auto max-w-6xl px-4 py-6">
        <div class="mb-4">
            <?php if (isset($component)) { $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-button','data' => ['href' => route('operator.exams.index')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('operator.exams.index'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $attributes = $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $component = $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
        </div>

        <?php if($errors->any()): ?>
            <div class="mb-4 rounded-lg border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-700">
                <?php echo e($errors->first()); ?>

            </div>
        <?php endif; ?>

        <div class="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            <?php $__empty_1 = true; $__currentLoopData = $attempts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attempt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php ($audit = $attempt->audits->first()); ?>
                <article class="rounded-xl border border-gray-200 bg-white p-4 shadow-sm">
                    <div class="flex items-start justify-between gap-3">
                        <div class="min-w-0">
                            <p class="truncate font-semibold text-gray-900"><?php echo e($attempt->user->name); ?></p>
                            <p class="truncate text-xs text-gray-500"><?php echo e($attempt->user->email); ?></p>
                        </div>
                        <span class="rounded bg-gray-100 px-2 py-1 text-xs uppercase text-gray-700"><?php echo e($attempt->status); ?></span>
                    </div>

                    <div class="mt-3 grid grid-cols-3 gap-2 text-xs">
                        <div class="rounded-lg bg-slate-100 px-2 py-2">
                            <p class="text-slate-500">Koneksi</p>
                            <?php if($attempt->status === \App\Models\ExamAttempt::STATUS_ACTIVE): ?>
                                <p class="font-semibold <?php echo e($attempt->is_online ? 'text-emerald-700' : 'text-amber-700'); ?>">
                                    <?php echo e($attempt->is_online ? 'Online' : 'Offline'); ?>

                                </p>
                            <?php else: ?>
                                <p class="font-semibold text-slate-700">-</p>
                            <?php endif; ?>
                        </div>
                        <div class="rounded-lg bg-slate-100 px-2 py-2">
                            <p class="text-slate-500">Sisa Waktu</p>
                            <p class="font-semibold text-slate-800">
                                <?php echo e($attempt->status === \App\Models\ExamAttempt::STATUS_ACTIVE ? gmdate('i:s', (int) $attempt->remaining_seconds) : '-'); ?>

                            </p>
                        </div>
                        <div class="rounded-lg bg-slate-100 px-2 py-2">
                            <p class="text-slate-500">Skor</p>
                            <p class="font-semibold text-slate-800"><?php echo e($attempt->score ?? '-'); ?></p>
                        </div>
                    </div>

                    <div class="mt-4 space-y-2 border-t border-slate-100 pt-3">
                        <?php if($attempt->status === \App\Models\ExamAttempt::STATUS_ACTIVE): ?>
                            <form method="POST" action="<?php echo e(route('operator.exams.force-submit', $attempt)); ?>" class="grid gap-2 md:grid-cols-[1fr_auto]">
                                <?php echo csrf_field(); ?>
                                <input type="text" name="reason" class="w-full rounded border border-gray-300 px-3 py-2 text-xs" placeholder="Alasan force submit" required>
                                <button class="rounded bg-amber-600 px-3 py-2 text-xs font-semibold text-white hover:bg-amber-700">Force Submit</button>
                            </form>
                        <?php else: ?>
                            <form method="POST" action="<?php echo e(route('operator.exams.reopen', $attempt)); ?>" class="grid gap-2 md:grid-cols-[1fr_auto]">
                                <?php echo csrf_field(); ?>
                                <input type="text" name="reason" class="w-full rounded border border-gray-300 px-3 py-2 text-xs" placeholder="Alasan reopen attempt" required>
                                <button class="rounded bg-indigo-600 px-3 py-2 text-xs font-semibold text-white hover:bg-indigo-700">Re-open</button>
                            </form>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('operator.exams.mark-issue', $attempt)); ?>" class="grid gap-2 md:grid-cols-[1fr_auto]">
                            <?php echo csrf_field(); ?>
                            <input type="text" name="reason" class="w-full rounded border border-gray-300 px-3 py-2 text-xs" placeholder="Catat kendala teknis peserta" required>
                            <button class="rounded bg-slate-700 px-3 py-2 text-xs font-semibold text-white hover:bg-slate-800">Log Issue</button>
                        </form>

                        <form method="POST" action="<?php echo e(route('operator.exams.manual-score', $attempt)); ?>" class="grid gap-2 md:grid-cols-[90px_1fr_auto]">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="intent" value="manual_essay_scoring">
                            <input type="number" name="score" min="0" class="w-full rounded border border-gray-300 px-3 py-2 text-xs" placeholder="Score" required>
                            <input type="text" name="reason" class="w-full rounded border border-gray-300 px-3 py-2 text-xs" placeholder="Alasan manual score" required>
                            <button class="rounded bg-emerald-600 px-3 py-2 text-xs font-semibold text-white hover:bg-emerald-700">Manual Score</button>
                        </form>
                    </div>

                    <div class="mt-4 rounded-lg bg-slate-50 px-3 py-2 text-xs text-slate-600">
                        <p class="font-semibold text-slate-700">Audit Terakhir</p>
                        <?php if($audit): ?>
                            <p class="mt-1 font-medium text-slate-800"><?php echo e($audit->action); ?></p>
                            <p><?php echo e($audit->reason ?: '-'); ?></p>
                            <p class="text-[11px] text-slate-500"><?php echo e($audit->created_at?->format('d M Y H:i')); ?></p>
                        <?php else: ?>
                            <p class="mt-1">Belum ada log.</p>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="rounded-xl border border-gray-200 bg-white px-4 py-6 text-center text-sm text-gray-500 md:col-span-2 xl:col-span-3">
                    Belum ada peserta yang mulai ujian.
                </div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\website_ujian\resources\views/operator/exams/show.blade.php ENDPATH**/ ?>