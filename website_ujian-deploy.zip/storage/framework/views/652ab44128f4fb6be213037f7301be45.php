<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold text-gray-800">Daftar Ujian</h2>
     <?php $__env->endSlot(); ?>

    <div id="peserta-exam-list" class="mx-auto max-w-6xl px-4 py-6" data-realtime-state-url="<?php echo e(route('peserta.exams.realtime-state')); ?>">
        <div class="mb-4">
            <?php if (isset($component)) { $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.back-button','data' => ['href' => route('dashboard')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('back-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('dashboard'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $attributes = $__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__attributesOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687)): ?>
<?php $component = $__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687; ?>
<?php unset($__componentOriginal5c84f04e4e4c3f6b2afa5416a6776687); ?>
<?php endif; ?>
        </div>

        <div class="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            <?php $__empty_1 = true; $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    $isNotStartedYet = $exam->ui_action === \App\Support\ExamUiAction::START_DISABLED && $exam->ui_state === \App\Support\ExamUiState::NOT_STARTED;
                    $isEnded = in_array($exam->ui_action, [\App\Support\ExamUiAction::START_DISABLED, \App\Support\ExamUiAction::CONTINUE_DISABLED], true) && $exam->ui_state === \App\Support\ExamUiState::FINISHED;
                    $cannotStart = $exam->ui_action === \App\Support\ExamUiAction::START_DISABLED;
                ?>
                <div
                    class="rounded-xl border border-gray-200 bg-white p-5 shadow-sm"
                    data-exam-card
                    data-exam-id="<?php echo e($exam->id); ?>"
                    data-start-at-ts="<?php echo e($exam->start_at?->getTimestamp()); ?>"
                    data-end-at-ts="<?php echo e($exam->end_at?->getTimestamp()); ?>"
                    data-start-display="<?php echo e($exam->start_at?->format('d M Y H:i')); ?>"
                    data-end-display="<?php echo e($exam->end_at?->format('d M Y H:i')); ?>"
                    data-attempt-status="<?php echo e($exam->my_attempt_status ?? ''); ?>"
                    data-current-action="<?php echo e($exam->ui_action); ?>"
                >
                    <h3 class="text-lg font-semibold text-gray-900"><?php echo e($exam->title); ?></h3>
                    <p class="mt-1 text-sm text-gray-600"><?php echo e($exam->start_at?->format('d M Y H:i')); ?> - <?php echo e($exam->end_at?->format('d M Y H:i')); ?></p>
                    <p class="mt-2 text-xs uppercase text-gray-500">Status: <span data-attempt-status-label><?php echo e($exam->my_attempt_status ?? 'belum mulai'); ?></span></p>

                    <div class="mt-4">
                        <?php if($exam->my_attempt_id): ?>
                            <a
                                href="<?php echo e(route('peserta.exams.result', $exam->my_attempt_id)); ?>"
                                data-result-link
                                class="<?php echo e($exam->ui_action === \App\Support\ExamUiAction::RESULT ? '' : 'hidden'); ?> rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700"
                            >
                                Lihat Hasil
                            </a>

                            <a
                                href="<?php echo e(route('peserta.exams.show', $exam->my_attempt_id)); ?>"
                                data-continue-link
                                class="<?php echo e($exam->ui_action === \App\Support\ExamUiAction::CONTINUE_ENABLED ? '' : 'hidden'); ?> rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700"
                            >
                                Lanjut Ujian
                            </a>

                            <button
                                type="button"
                                disabled
                                data-continue-disabled
                                class="<?php echo e(in_array($exam->ui_action, [\App\Support\ExamUiAction::CONTINUE_DISABLED, \App\Support\ExamUiAction::WAITING_RESULT], true) ? '' : 'hidden'); ?> cursor-not-allowed rounded-lg bg-slate-400 px-4 py-2 text-sm font-semibold text-white"
                            >
                                <?php echo e($exam->ui_action === \App\Support\ExamUiAction::WAITING_RESULT ? 'Menunggu Hasil' : 'Lanjut Ujian'); ?>

                            </button>

                            <p class="mt-2 text-xs <?php echo e(in_array($exam->ui_action, [\App\Support\ExamUiAction::CONTINUE_DISABLED, \App\Support\ExamUiAction::WAITING_RESULT], true) && $exam->ui_message ? '' : 'hidden'); ?> <?php echo e(($exam->ui_message_tone ?? '') === 'amber' ? 'text-amber-700' : 'text-rose-700'); ?>" data-continue-expired-msg><?php echo e($exam->ui_message); ?></p>

                        <?php else: ?>
                            <form method="POST" action="<?php echo e(route('peserta.exams.start', $exam)); ?>">
                                <?php echo csrf_field(); ?>
                                <button
                                    type="submit"
                                    data-start-button
                                    <?php echo e($cannotStart ? 'disabled' : ''); ?>

                                    class="rounded-lg px-4 py-2 text-sm font-semibold text-white <?php echo e($cannotStart ? 'cursor-not-allowed bg-slate-400' : 'bg-indigo-600 hover:bg-indigo-700'); ?>"
                                >
                                    Start Exam
                                </button>
                            </form>
                            <p class="mt-2 text-xs <?php echo e($exam->ui_message ? '' : 'hidden'); ?> <?php echo e($isNotStartedYet ? 'text-amber-700' : ($isEnded ? 'text-rose-700' : 'text-slate-600')); ?>" data-start-message><?php echo e($exam->ui_message); ?></p>
                        <?php endif; ?>

                        <?php if($exam->my_attempt_id && in_array($exam->my_attempt_status, ['submitted', 'finished'], true)): ?>
                            <p class="mt-2 hidden text-xs text-slate-600" data-start-message></p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-sm text-gray-500">Belum ada ujian yang dipublish.</p>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\website_ujian\resources\views/peserta/exams/index.blade.php ENDPATH**/ ?>