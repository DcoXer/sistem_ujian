<section id="mulai-ujian" class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
    <h2 class="text-lg font-semibold text-slate-900">Mulai Ujian</h2>
    <?php if($activeExam): ?>
        <p class="mt-2 text-sm text-slate-600">Ujian aktif saat ini:</p>
        <p class="mt-1 text-base font-semibold text-slate-900"><?php echo e($activeExam->title); ?></p>
        <a href="<?php echo e(route('peserta.exams.index')); ?>" class="mt-4 inline-flex rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white hover:bg-slate-800">
            Mulai / Lanjut Ujian
        </a>
    <?php else: ?>
        <?php if(!empty($activeExamExpiredMessage)): ?>
            <p class="mt-2 text-sm text-amber-700"><?php echo e($activeExamExpiredMessage); ?></p>
            <?php if(!empty($upcomingExam)): ?>
                <p class="mt-2 text-xs text-slate-500">Ujian terdekat: <?php echo e($upcomingExam->title); ?> (<?php echo e($upcomingExam->start_at?->format('d M Y H:i')); ?>)</p>
            <?php endif; ?>
        <?php else: ?>
            <p class="mt-2 text-sm text-amber-700">Belum ada ujian aktif. Tunggu info jadwal selanjutnya.</p>
        <?php endif; ?>
    <?php endif; ?>
</section>

<section id="jawab-soal" class="grid gap-4 lg:grid-cols-2">
    <article class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <h3 class="text-base font-semibold text-slate-900">Sesi Pengerjaan</h3>
        <?php if($myInProgressAttempt): ?>
            <p class="mt-2 text-sm text-slate-600">Anda masih punya attempt aktif. Lanjutkan dari jawaban terakhir.</p>
            <a href="<?php echo e(route('peserta.exams.show', $myInProgressAttempt->id)); ?>" class="mt-4 inline-flex rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700">
                Lanjut Kerjakan
            </a>
        <?php else: ?>
            <p class="mt-2 text-sm text-slate-600">Belum ada attempt aktif untuk saat ini.</p>
            <a href="<?php echo e(route('peserta.exams.index')); ?>" class="mt-4 inline-flex rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-100">
                Buka Daftar Ujian
            </a>
        <?php endif; ?>
    </article>

    <article id="nilai-saya" class="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <div class="mb-3 flex items-center justify-between gap-2">
            <h3 class="text-base font-semibold text-slate-900">Nilai Saya</h3>
            <?php if($myLatestSubmittedAttempt): ?>
                <a href="<?php echo e(route('peserta.exams.result', $myLatestSubmittedAttempt->id)); ?>" class="rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-1 text-xs font-semibold text-indigo-700 hover:bg-indigo-100">
                    Hasil Terakhir
                </a>
            <?php endif; ?>
        </div>
        <div class="space-y-2">
            <?php $__empty_1 = true; $__currentLoopData = $myScores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="flex items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-sm">
                    <span class="text-slate-800"><?php echo e($score->match_title); ?></span>
                    <span class="font-semibold text-slate-900"><?php echo e((int) $score->score); ?> pts</span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-sm text-slate-500">Belum ada nilai untuk akun ini.</p>
            <?php endif; ?>
        </div>
    </article>
</section>
<?php /**PATH C:\laragon\www\website_ujian\resources\views/dashboard/role-peserta.blade.php ENDPATH**/ ?>