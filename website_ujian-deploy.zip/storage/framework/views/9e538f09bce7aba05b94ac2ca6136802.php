<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Sistem Ujian')); ?></title>
        <link rel="icon" type="image/svg+xml" href="<?php echo e(asset('favicon.svg')); ?>">

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=plus-jakarta-sans:400,500,600,700,800&display=swap" rel="stylesheet" />

        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <style>[x-cloak]{display:none !important;}</style>
    </head>
    <body class="font-['Plus_Jakarta_Sans'] antialiased">
        <?php
            $user = auth()->user();
            $role = $user?->role ?? config('sidebar.default_role');
            $sidebarSections = config("sidebar.roles.$role", config('sidebar.roles.'.config('sidebar.default_role'), []));
            $examUiActions = \App\Support\ExamUiAction::all();
            $examUiStates = \App\Support\ExamUiState::all();
            $popupStatus = session('status');
            $popupError = session('error')
                ?? $errors->first('delete')
                ?? $errors->first('publish')
                ?? $errors->first('role');
            $userInitial = strtoupper(substr(trim((string) ($user?->name ?? 'U')), 0, 1));
        ?>

        <div
            id="app-layout-root"
            class="min-h-screen bg-slate-100"
            data-popup-status="<?php echo e($popupStatus ?? ''); ?>"
            data-popup-error="<?php echo e($popupError ?? ''); ?>"
            data-server-now-ms="<?php echo e(now()->getTimestamp() * 1000); ?>"
            data-exam-ui-actions='<?php echo json_encode($examUiActions, 15, 512) ?>'
            data-exam-ui-states='<?php echo json_encode($examUiStates, 15, 512) ?>'
        >
            <div id="sidebar-backdrop" class="fixed inset-0 z-30 hidden bg-slate-900/50 lg:hidden"></div>

            <?php if (isset($component)) { $__componentOriginal2880b66d47486b4bfeaf519598a469d6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2880b66d47486b4bfeaf519598a469d6 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sidebar','data' => ['role' => $role,'sections' => $sidebarSections]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['role' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($role),'sections' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($sidebarSections)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2880b66d47486b4bfeaf519598a469d6)): ?>
<?php $attributes = $__attributesOriginal2880b66d47486b4bfeaf519598a469d6; ?>
<?php unset($__attributesOriginal2880b66d47486b4bfeaf519598a469d6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2880b66d47486b4bfeaf519598a469d6)): ?>
<?php $component = $__componentOriginal2880b66d47486b4bfeaf519598a469d6; ?>
<?php unset($__componentOriginal2880b66d47486b4bfeaf519598a469d6); ?>
<?php endif; ?>

            <div class="min-h-screen lg:pl-72">
                <header class="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur">
                    <div class="flex items-center justify-between gap-4 px-4 py-4 sm:px-6 lg:px-8">
                        <div class="flex items-center gap-3">
                            <button id="sidebar-open" type="button" class="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-100 lg:hidden">
                                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'menu','class' => 'h-5 w-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'menu','class' => 'h-5 w-5']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                            </button>
                            <div class="text-slate-900">
                                <?php if(isset($header)): ?>
                                    <?php echo e($header); ?>

                                <?php else: ?>
                                    <h1 class="text-2xl font-bold">Dashboard</h1>
                                <?php endif; ?>
                                <p id="app-live-clock" class="text-sm text-slate-500" data-timezone="<?php echo e(config('app.timezone', 'Asia/Jakarta')); ?>"><?php echo e(now()->format('l, d M Y H:i:s')); ?> WIB</p>
                            </div>
                        </div>

                        <details class="relative">
                            <summary class="list-none inline-flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-2 text-sm font-medium text-slate-700 shadow-sm hover:bg-slate-50">
                                <?php if($user?->profile_photo_url): ?>
                                    <img src="<?php echo e($user->profile_photo_url); ?>" alt="Avatar" class="h-8 w-8 rounded-full object-cover ring-1 ring-slate-200">
                                <?php else: ?>
                                    <span class="inline-flex h-8 w-8 items-center justify-center rounded-full bg-slate-200 text-xs font-bold text-slate-700">
                                        <?php echo e($userInitial); ?>

                                    </span>
                                <?php endif; ?>
                                <span><?php echo e($user?->name); ?></span>
                                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chevron-down','class' => 'h-4 w-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron-down','class' => 'h-4 w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                            </summary>
                            <div class="absolute right-0 mt-2 w-44 rounded-lg border border-slate-200 bg-white p-1 shadow-lg">
                                <a href="<?php echo e(route('profile.edit')); ?>" class="block rounded-md px-3 py-2 text-sm text-slate-700 hover:bg-slate-100">Profile</a>
                                <form method="POST" action="<?php echo e(route('logout')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="w-full rounded-md px-3 py-2 text-left text-sm text-red-600 hover:bg-red-50">Logout</button>
                                </form>
                            </div>
                        </details>
                    </div>
                </header>

                <main class="px-4 py-6 sm:px-6 lg:px-8">
                    <?php echo e($slot); ?>

                </main>
            </div>
        </div>

        <div id="app-toast-container" class="pointer-events-none fixed left-1/2 top-20 z-[100] flex w-[calc(100%-1rem)] max-w-md -translate-x-1/2 flex-col gap-2 sm:top-6 sm:w-full"></div>

        <div id="app-confirm-modal" class="fixed inset-0 z-[110] hidden">
            <div id="app-confirm-backdrop" class="absolute inset-0 bg-slate-900/60"></div>
            <div class="relative z-10 flex min-h-full items-center justify-center p-4">
                <div class="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-5 shadow-xl">
                    <h3 id="app-confirm-title" class="text-lg font-bold text-slate-900">Konfirmasi</h3>
                    <p id="app-confirm-message" class="mt-2 text-sm text-slate-600">Apakah Anda yakin?</p>
                    <div class="mt-5 flex items-center justify-end gap-2">
                        <button id="app-confirm-cancel" type="button" class="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-100">
                            Batal
                        </button>
                        <button id="app-confirm-ok" type="button" class="rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-700">
                            Ya, lanjutkan
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\laragon\www\website_ujian\resources\views/layouts/app.blade.php ENDPATH**/ ?>