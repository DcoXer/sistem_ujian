<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold text-gray-800">Hasil Ujian</h2>
     <?php $__env->endSlot(); ?>

    <div class="mx-auto max-w-3xl px-4 py-6">
        <div class="rounded-xl border border-gray-200 bg-white p-6 text-center">
            <p class="text-sm uppercase tracking-wide text-gray-500"><?php echo e($attempt->exam->title); ?></p>
            <p class="text-sm uppercase tracking-wide text-green-500">Nilai</p>
            <p class="mt-2 text-4xl font-bold text-green-500"><?php echo e($attempt->score ?? 0); ?></p>
            <p class="mt-1 text-sm text-green-700">Status: <?php echo e($attempt->status); ?></p>
            <p class="mt-4 text-xs text-gray-500">Jawaban sudah dikunci. <br>Ujian selesai.</p>

            <a href="<?php echo e(route('peserta.exams.index')); ?>" class="mt-5 inline-flex rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-700">
                Kembali ke Daftar Ujian
            </a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\website_ujian\resources\views/peserta/exams/result.blade.php ENDPATH**/ ?>